#تحلیل حساسیت

from gurobipy import Model, GRB
import pandas as pd
import matplotlib.pyplot as plt

def modelsover(T,MAX_A,limit_machine_2):
#Define Model
    mdl = Model('Machines') 
    #Define Variables 
    N1 = [i for i in range(1, 5)]
    N2 = [i for i in range(1, 6) if i != 3]
    N3 = [i for i in range(1, 6) if i!=1 and i!=4]
    L=['AB1','AB2','AC2','BC2','AC3','AB4','BC5']

    A = mdl.addVars(N1, vtype=GRB.CONTINUOUS,name='A')
    B = mdl.addVars(N2, vtype=GRB.CONTINUOUS,name='B')
    C = mdl.addVars(N3, vtype=GRB.CONTINUOUS,name='C')
    Y = mdl.addVars(L, vtype=GRB.BINARY,name='Y')
    U = mdl.addVar(name="U")
    
    #Define Objective Function
    mdl.modelSense = GRB.MINIMIZE
    mdl.setObjective(U)

    #Define Constraints
    mdl.addConstr(U >= A[4] + T[0][4])
    mdl.addConstr(U >= B[5] + T[1][5])
    mdl.addConstr(U >= C[5] + T[2][5])

    for i in N1 :
        for j in N1:
            if j > i :
                for k in range(1 ,len(N1)+1):
                    if k==i :
                        mdl.addConstr(A[i] + T[0][k] <= A[j])
    for i in N2 :
        for j in N2:
            if j > i :
                for k in range(1 ,len(N2)+1):
                    if k==i :
                        mdl.addConstr(B[i] + T[1][k] <= B[j])
    for i in N3 :
        for j in N3:
            if j > i :
                for k in range(1 ,len(N3)+1):
                    if k==i :
                        mdl.addConstr(C[i] + T[2][k] <= C[j]) 

    mdl.addConstr(C[5] + T[2][5]+ 15 <= B[5]+ T[1][5])   
    mdl.addConstr(A[4]+ T[0][4]<= MAX_A )
    #machine 1
    mdl.addConstr((Y['AB1']== 1) >> (A[1] + T[0][1] + 4 <= B[1] ), name='1')
    mdl.addConstr((Y['AB1']== 0) >> (B[1] + T[1][1] + 4 <= A[1] ), name='2')
    #machine 2
    mdl.addConstr((Y['AB2']== 1) >> (A[2] + T[0][2] + limit_machine_2 <= B[2] ), name='3')
    mdl.addConstr((Y['AB2']== 0) >> (B[2] +T[1][2] + limit_machine_2 <= A[2] ), name='4')

    mdl.addConstr((Y['AC2']== 1) >> (A[2] + T[0][2] + limit_machine_2 <= C[2] ), name='5')
    mdl.addConstr((Y['AC2']== 0) >> (C[2] + T[1][2] + limit_machine_2 <= A[2] ), name='6')

    mdl.addConstr((Y['BC2']== 1) >> (B[2] + T[1][2] + limit_machine_2 <= C[2] ), name='7')
    mdl.addConstr((Y['BC2']== 0) >> (C[2] + T[2][2] + limit_machine_2 <= B[2] ), name='8')
    #machine 3
    mdl.addConstr((Y['AC3']== 1) >> (A[3] + T[0][3] + 5 <= C[3] ), name='9')
    mdl.addConstr((Y['AC3']== 0) >> (C[3] + T[2][3] + 5 <= A[3] ), name='10')
    #machine 4
    mdl.addConstr((Y['AB4']== 1) >> (A[4] + T[0][4] + 20 <= B[4] ), name='11')
    mdl.addConstr((Y['AB4']== 0) >> (B[4] + T[1][4] + 20 <= A[4] ), name='12')
#machine 5
    mdl.addConstr((Y['BC5']== 1) >> (B[5] + T[1][5]  <= C[5] ), name='13')
    mdl.addConstr((Y['BC5']== 0) >> (C[5] + T[2][5] <= B[5] ), name='14')
    mdl.optimize()
    mdl.display()
    
    variable_values = {}

# Extract variable values
    for var in mdl.getVars():
        variable_values[var.varName] = var.x

# Create a DataFrame from the variable values
    variables_df = pd.DataFrame(variable_values.items(), columns=['Variable', 'Value'])

# Display the DataFrame
    print("Variable Values:")
    print(variables_df)
    objective_function_value = mdl.objVal
    # Return the objective function value
    return objective_function_value
    
    

def sensetivity_analysis_1():
    limit_machine_2 =10
    MAX_A = 60
    objective_function_values = []
    for i in range(1,21,1):
        T = [[0,10,6,12,22,0],[0,8,i,0,19,7],[0,0,9,14,0,6]]
        objective_function_value = modelsover(T, MAX_A, limit_machine_2)  # You need to define modelsover function
        objective_function_values.append(objective_function_value)
    plt.figure(figsize=(10, 6))
    plt.plot(range(1, 21), objective_function_values, marker='o', color='b', linestyle='-')
    plt.xlabel('Value of i')
    plt.ylabel('Objective Function Value')
    plt.title('Sensitivity Analysis: Varying i in sensetivity_analysis_1()')
    plt.grid(True)
    plt.show()
sensetivity_analysis_1()

def sensetivity_analysis_2():
    limit_machine_2 =10
    MAX_A = 60
    objective_function_values = []
    for i in range(1,16,1):
        T = [[0,10,6,12,i,0],[0,8,9,0,19,7],[0,0,9,14,0,6]]
        objective_function_value = modelsover(T, MAX_A, limit_machine_2)  # You need to define modelsover function
        objective_function_values.append(objective_function_value)
    plt.figure(figsize=(10, 6))
    plt.plot(range(1, 16), objective_function_values, marker='o', color='b', linestyle='-')
    plt.xlabel('Value of i')
    plt.ylabel('Objective Function Value')
    plt.title('Sensitivity Analysis: Varying i in sensetivity_analysis_2()')
    plt.grid(True)
    plt.show()
sensetivity_analysis_2()

def sensetivity_analysis_3():
    limit_machine_2 =10
    MAX_A = 60
    objective_function_values=[]
    for i in range(1,19,1):
        T = [[0,10,6,12,22,0],[0,8,9,0,19,7],[0,0,9,14,0,i]]
        objective_function_value = modelsover(T, MAX_A, limit_machine_2)  # You need to define modelsover function
        objective_function_values.append(objective_function_value)
    plt.figure(figsize=(10, 6))
    plt.plot(range(1, 19), objective_function_values, marker='o', color='b', linestyle='-')
    plt.xlabel('Value of i')
    plt.ylabel('Objective Function Value')
    plt.title('Sensitivity Analysis: Varying i in sensetivity_analysis_3()')
    plt.grid(True)
    plt.show()
sensetivity_analysis_3()

def sensetivity_analysis_4():
    limit_machine_2 =10
    T = [[0,10,6,12,22,0],[0,8,9,0,19,7],[0,0,9,14,0,6]]
    objective_function_values =[]
    for i in range(50,81,1):
        MAX_A = i
        objective_function_value = modelsover(T, MAX_A, limit_machine_2)  # You need to define modelsover function
        objective_function_values.append(objective_function_value)
    plt.figure(figsize=(10, 6))
    plt.plot(range(50, 81), objective_function_values, marker='o', color='b', linestyle='-')
    plt.xlabel('Value of i')
    plt.ylabel('Objective Function Value')
    plt.title('Sensitivity Analysis: Varying i in sensetivity_analysis_4()')
    plt.grid(True)
    plt.show()
sensetivity_analysis_4()

def sensetivity_analysis_5():
    MAX_A = 60
    T = [[0,10,6,12,22,0],[0,8,9,0,19,7],[0,0,9,14,0,6]]
    objective_function_values =[]
    for i in range(3,16,1):
        limit_machine_2 = i
        objective_function_value = modelsover(T, MAX_A, limit_machine_2)  # You need to define modelsover function
        objective_function_values.append(objective_function_value)
    plt.figure(figsize=(10, 6))
    plt.plot(range(3, 16), objective_function_values, marker='o', color='b', linestyle='-')
    plt.xlabel('Value of i')
    plt.ylabel('Objective Function Value')
    plt.title('Sensitivity Analysis: Varying i in sensetivity_analysis_5()')
    plt.grid(True)
    plt.show()
sensetivity_analysis_5()